var config = {
    apiKey: "AIzaSyCrJczJcwMiBG-zTTaYbHUbvIH9cdba7DE",
    authDomain: "bikcraft-11ff6.firebaseapp.com",
    databaseURL: "https://bikcraft-11ff6.firebaseio.com",
    projectId: "bikcraft-11ff6",
    storageBucket: "bikcraft-11ff6.appspot.com",
    messagingSenderId: "598203752168"
  };
  firebase.initializeApp(config);